© Copyright Camel Audio Limited

We share this plugin owned by Camel Audio simply because we do not find at the official website of Camel Audio. Please let us know if this has changed to link directly to the official download link of Camel Audio again. You can write to: audiopluginsforfree@gmail.com.

Thanks for your help

www.audiopluginsforfree.com